<?php
include('model/usersModel.php');
class usersController
{
    private $model;

    public function __construct()
    {
        $this->model = new usersModel;
    }

    public function formInscription()
    {
        include('view/inscription.php');
    }

    public function setUser()
    {
        $nom = $_POST['nom'];
        $prenom = $_POST['prenom'];
        $email = $_POST['email'];
        $tel = $_POST['tel'];
        $mdp = password_hash($_POST["mdp"], PASSWORD_DEFAULT); //bcrypt

        if ($this->model->setUser($nom, $prenom, $email, $tel, $mdp)) {
            echo "inscription OK";
        } else {
            $this->formInscription();
        }
    }

    
    public function formConnexion()
    {
        include('view/connexion.php');
    }


    public function getUserConnexion()
    {
        $email = $_POST['email'];
        $mdp = $_POST["mdp"]; //bcrypt
        
        $user = $this->model->getUserByEmail($email);
        
        if (password_verify($mdp, $user['mdp'])) {
                 
            $_SESSION['id_user'] = $user['id_user'];
            $_SESSION['nom'] = $user['nom'];
            $_SESSION['prenom'] = $user['prenom'];
            $_SESSION['id_role'] = $user['id_role'];
            $_SESSION['role'] = $user['role'];
    
            header("Location: index.php"); // redirection vers index.php
        } else {
            $this->formConnexion();
        }
    }



}