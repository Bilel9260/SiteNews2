<?php
include_once('model/articlesModel.php');

class articlesController
{
    private $model;

    public function __construct()
    {
        $this->model = new articlesModel;
    }

    public function getArticles()
    {
        $articles = $this->model->getArticles();
        include('view/articles.php');
    }

    public function formAjoutArticle()
    {
        include('view/formAjoutArticle.php');
    }

    
    public function setArticle()
    {
 


        $titre = $_POST['titre'];
        $contenu = $_POST['contenu'];

        $image = fileUpload::image();
       
        $id_user = $_SESSION['id_user']; // je recupere id_user de la session
        $id_categorie = $_POST['id_categorie'];
      
        if ($this->model->setArticle($titre, $contenu, $image, $id_user, $id_categorie)) {
            echo "Article ajouté";
        } else {
            $this->formAjoutArticle();
        }
    }

}