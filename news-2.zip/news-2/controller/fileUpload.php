<?php

class fileUpload
 {
    public static function image()
    {
        //  var_dump($_FILES['fichier']);
        $fichier = explode('.', $_FILES['fichier']['name']);
        $extension = end($fichier);

        $typeFichierTmp = mime_content_type($_FILES['fichier']['tmp_name']);
        $chemin = 'images/' . microtime(true) . '.' . $extension;

        $typeFichierAccepter = ['image/jpeg', 'image/png'];
        $typeExtAccepter = ['jpg', 'png', 'gif'];
        // in_array(test,tab)


        if (in_array($typeFichierTmp, $typeFichierAccepter) && in_array($extension, $typeExtAccepter)) {
            if (move_uploaded_file($_FILES['fichier']['tmp_name'], $chemin)) {
                return $chemin;
            } else {
                return false;
            }
        } else {
            return false;
        }
    }

 }