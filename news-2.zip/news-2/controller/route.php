<?php
include_once('model/bdd.php');
include('controller/usersController.php');
include('controller/articlesController.php');
include('controller/fileUpload.php');
// http://localhost/epsi_dwwm/php/poo/news/index.php?p=inscription

$page = @$_GET['p'];

switch ($page) {
    case 'inscription': // index.php?p=inscription
        $user = new usersController;
        $user->formInscription(); // view/inscription.php
        break;

    case 'connexion':
        $user = new usersController();
        if (isset($_POST['email'])) {
            $user->getUserConnexion();
        } else {
            $user->formConnexion();
        }
        break;

    case 'deconnexion':
        $_SESSION = array(); // deconnexion
        header("Location: index.php"); // redirection vers index.php
        break;

    case 'confirmationinsciption': // index.php?p=confirmationinsciption
        $user = new usersController();
        if (isset($_POST['nom'])) {
            $user->setUser();
        } else {
            $user->formInscription();
        }
        break;

    case 'articles':
        $blabla = new articlesController;
        $blabla->getArticles();
        break;

    case 'ajouterArticle':
        $user = new articlesController;
        if (isset($_POST['titre'])) {
            $user->setArticle();
        } else {
            $user->formAjoutArticle();
        }
        break;



    default:
        $blabla = new articlesController;
        $blabla->getArticles();
        break;
}