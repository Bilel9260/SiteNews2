<?php

class BDD
{

    public static function connexion()
    {
        try {
            $bdd = new PDO("mysql:host=localhost;dbname=news", "root", "root");
            $bdd->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            //  echo "ok";
            return $bdd;
        } catch (Exception $e) {
            die("problemme de connextion BDD : $e");
        }
    }
}

?>