<?php

class articlesModel
{

    private $bdd;

    public function __construct()
    {
        $this->bdd=BDD::connexion();
    }

    public function getArticles()
    {
        return $this->bdd->query("SELECT * FROM articles")->fetchAll();
    }

    public function setArticle($titre,$contenu,$image,$id_user,$id_categorie)
    {
     
        $date = date("Y-m-d");
        $article = $this->bdd->prepare("INSERT INTO articles(titre,contenu,image,dateCreation,id_user,id_categorie) VALUES(?,?,?,?,?,?)");
        return $article->execute([$titre,$contenu,$image,$date,$id_user,$id_categorie]);
    }

}