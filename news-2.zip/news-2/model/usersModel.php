<?php

class usersModel
{

    private $bdd;

    public function __construct()
    {
        $this->bdd=BDD::connexion();
    }

    public function setUser($nom,$prenom,$email,$tel,$mdp)
    {
        $user=$this->bdd->prepare('INSERT INTO users(nom,prenom,email,tel,mdp) VALUES(?,?,?,?,?)');
        return $user->execute([$nom,$prenom,$email,$tel,$mdp]);
    }

    public function getUsers()
    {
        return $this->bdd->query('select * from users')->fetchAll();
    }

    public function getUserById($id)
    {
        $sql = "SELECT * FROM users 
                INNER JOIN affecter ON users.id_user=affecter.id_user
                INNER JOIN roles ON roles.id_role=affecter.id_role
                WHERE id_user=$id";

        return $this->bdd->query($sql)->fetch();
    }

    public function getUserByEmail($email)
    {
        $sql = "SELECT * FROM users 
                INNER JOIN affecter ON users.id_user=affecter.id_user
                INNER JOIN roles ON roles.id_role=affecter.id_role
                WHERE email='$email'";
        return $this->bdd->query($sql)->fetch();
    }
    

}
