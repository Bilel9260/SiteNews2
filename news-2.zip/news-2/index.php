<?php
session_start();

include('view/header.php');
include('controller/route.php');
include('view/footer.php');


?>