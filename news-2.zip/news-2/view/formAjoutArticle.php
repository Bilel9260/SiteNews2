<h1>Ajouter un article</h1>

<form action="" method="post" enctype="multipart/form-data" >

    Titre <input type="text" name="titre"><br>
    Contenu <textarea name="contenu" id="contenu" cols="30" rows="10"></textarea><br>

    Image  <input type="file" name="fichier"><br> 
    Categorie <input type="text" name="id_categorie"><br> 

    <br>
    <button>Envoyer</button>

</form>