<?php
//var_dump($articles);
/*
foreach ($articles as $article) {
    echo "<div>
    <h1>{$article['titre']}</h1>
    <img src='{$article['image']}'>
    <p>{$article['contenu']}</p>
    </div>";
}
*/

?>
  <div class="flex">
<?php foreach ($articles as $article) { ?>
    <div style="  padding: 10px;">
        <h1>
            <?= $article['titre'] ?>
        </h1>
        <img src="<?= $article['image'] ?>" class="image" >
        <p class="blabla">
            <?= $article['contenu'] ?>
        </p>
    </div>
<?php } ?>
</div>