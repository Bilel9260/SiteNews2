<h1>Inscription</h1>

<form action="?p=confirmationinsciption" method="post">

    Nom <input type="text" name="nom"><br>
    Prenom <input type="text" name="prenom"><br>
    Email <input type="email" name="email"><br>
    Tel <input type="text" name="tel"><br>
    mot de passe <input type="password" name="mdp"><br>
    

    <br>
    <button>Envoyer</button>

</form>