<h1>Connexion</h1>

<form action="" method="post">

Email <input type="text" name="email"><br>
mot de passe <input type="password" name="mdp"><br>
<button>Envoyer</button>

</form>