<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>

    <link rel="stylesheet" href="css/style.css">
</head>

<body>

    <header>

        <img src="https://picsum.photos/100/50">
        <nav>
            <a href="index.php?p=articles">articles</a>
            <a href="index.php?p=inscription">inscription</a>


            <?php if (isset($_SESSION['nom'])) { ?>
                Bonjour
                <?= $_SESSION['prenom'] ?>
                <?= $_SESSION['nom'] ?>
                (<?= $_SESSION['role'] ?>)


                <?php if ($_SESSION['id_role'] == 2) { ?>
                    <a href="index.php?p=ajouterArticle">Ajouter un article</a>
                <?php } ?>

                <a href="index.php?p=deconnexion">deconnexion</a>
            <?php } else { ?>
                <a href="index.php?p=connexion">connexion</a>
            <?php } ?>


        </nav>
    </header>
    <main>